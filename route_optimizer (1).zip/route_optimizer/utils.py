def display_graph(graph):
    print("\nAvailable locations:")
    for node in graph:
        print(node, end=" ")
    print()
