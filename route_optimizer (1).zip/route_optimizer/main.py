from graph import Graph
from utils import display_graph

def build_sample_graph():
    g = Graph()

    g.add_edge('A', 'B', 4)
    g.add_edge('A', 'C', 2)
    g.add_edge('B', 'C', 5)
    g.add_edge('B', 'D', 10)
    g.add_edge('C', 'D', 3)
    g.add_edge('C', 'E', 4)
    g.add_edge('D', 'F', 11)
    g.add_edge('E', 'F', 2)

    return g

def main():
    g = build_sample_graph()

    display_graph(g.graph)

    source = input("Enter source location: ").strip()
    destination = input("Enter destination location: ").strip()

    if source not in g.graph or destination not in g.graph:
        print("\nInvalid source or destination!")
        return

    distances, parent = g.dijkstra(source)
    path = g.get_path(parent, source, destination)

    if path and distances[destination] != float('inf'):
        print("\nShortest Route:", " -> ".join(path))
        print("Total Distance:", distances[destination], "km")
    else:
        print("\nNo route found!")

if __name__ == "__main__":
    main()
